package pacote;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Arquivo {

    private FileWriter arqw;
    private BufferedWriter escritor;
    private List<Aluno> listAlunos;
    public String nomeArquivo;

    public Arquivo(String nomeArquivo) {
        this.nomeArquivo = nomeArquivo;
        listAlunos = new ArrayList<>();
    }

    public void gravaArquivo(Aluno a) {
        try {
            arqw = new FileWriter(nomeArquivo + ".txt", true); 
            escritor = new BufferedWriter(arqw);
            
            
            escritor.write(a.toString());
            escritor.newLine();  
            
            escritor.close();
            arqw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        public List<Aluno> leArquivo(){
        	
        }
    }
}

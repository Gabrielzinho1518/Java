package pacote;

import java.util.Scanner;

public class MediaDisciplinas {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        double[][] notas = new double[3][4]; // 3 alunos, 4 disciplinas
        double[] medias = new double[4];
        
        for (int i = 0; i < 3; i++) {
            System.out.println("Aluno " + (i + 1) + ":");
            for (int j = 0; j < 4; j++) {
                System.out.print("Digite a nota da disciplina " + (j + 1) + ": ");
                notas[i][j] = scanner.nextDouble();
            }
        }
        
        // Calculando a média de cada disciplina
        for (int j = 0; j < 4; j++) {
            double soma = 0;
            for (int i = 0; i < 3; i++) {
                soma += notas[i][j];
            }
            medias[j] = soma / 3;
        }
        
        // Exibindo as médias
        System.out.println("Médias das disciplinas:");
        for (int j = 0; j < 4; j++) {
            System.out.println("Disciplina " + (j + 1) + ": " + medias[j]);
        }
        
        scanner.close();
    }
}

package pacote2;

public class Livro {
    private String titulo;
    private String autor;
    private int anoPublicacao;
    private String genero;
    private boolean emprestado;

    public void definirLivro(String t, String a, int ano, String g) {
        titulo = t;
        autor = a;
        anoPublicacao = ano;
        genero = g;
        emprestado = false; 
    }

    public String obterInformacoes() {
        String status = emprestado ? "Emprestado" : "Disponível";
        return "Título: " + titulo + "\nAutor: " + autor + "\nAno: " + anoPublicacao +
               "\nGênero: " + genero + "\nStatus: " + status;
    }

    public boolean emprestar() {
        if (emprestado) {
            return false; 
        }
        emprestado = true;
        return true;
    }

    public boolean devolver() {
        if (!emprestado) {
            return false; 
        }
        emprestado = false;
        return true;
    }
}

package pacote;

import java.util.Scanner;

public class ParesImpares {
    public static void main(String[] args) {
        // Criação de um Scanner para ler dados do usuário
        Scanner scanner = new Scanner(System.in);

        // Vetor para armazenar os 10 números
        int[] numeros = new int[10];
        int contPares = 0;
        int contImpares = 0;

        // Leitura dos 10 números inteiros
        System.out.println("Digite 10 números inteiros:");

        for (int i = 0; i < 10; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();

            // Verificação se o número é par ou ímpar
            if (numeros[i] % 2 == 0) {
                contPares++;
            } else {
                contImpares++;
            }
        }

        // Exibindo os resultados
        System.out.println("Quantidade de números pares: " + contPares);
        System.out.println("Quantidade de números ímpares: " + contImpares);

        // Fechando o scanner
        scanner.close();
    }
}

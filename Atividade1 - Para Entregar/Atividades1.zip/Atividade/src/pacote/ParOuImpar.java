package pacote;

import java.util.Scanner;

public class ParOuImpar {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite um número:\n");
		double num = sc.nextDouble();
		
		if (num % 2 == 0) {
			System.out.println("O Número é par");
		}
		else {
			System.out.println("O Número é ímpar");
		}
	}
		
}

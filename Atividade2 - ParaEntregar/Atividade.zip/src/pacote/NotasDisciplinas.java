package pacote;

public class NotasDisciplinas {
    public static void main(String[] args) {

        double[][] notas = {
            {7.5, 8.0, 6.5, 9.0}, // Notas do aluno 1
            {8.5, 7.0, 9.5, 6.0}, // Notas do aluno 2
            {9.0, 8.5, 7.0, 8.0}  // Notas do aluno 3
        };


        for (int j = 0; j < 4; j++) {
            double maiorNota = notas[0][j];
            double menorNota = notas[0][j];

            for (int i = 1; i < 3; i++) {
                if (notas[i][j] > maiorNota) {
                    maiorNota = notas[i][j];
                }
                if (notas[i][j] < menorNota) {
                    menorNota = notas[i][j];
                }
            }

            System.out.println("Disciplina " + (j+1) + ":");
            System.out.println("Nota mais alta: " + maiorNota);
            System.out.println("Nota mais baixa: " + menorNota);
            System.out.println();
        }
    }
}

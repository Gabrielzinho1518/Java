package pacote;

public class Onibus extends Carro {
	// Classe onibus extende Carro
	// esta classe onibus herda tudo que esta na classe Carro

	protected String modelo;
	
	public String getModelo() {
		return modelo;
	}
	
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	
}

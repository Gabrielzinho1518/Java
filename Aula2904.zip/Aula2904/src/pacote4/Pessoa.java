package pacote4;

public class Pessoa {
	
	public String nome;
	
	public void dizerOla() {
		System.out.println("Olá");
	}
	
	public void dizerOla(String nome) {
		System.out.println("Olá\n"+nome+"!");
	}
}

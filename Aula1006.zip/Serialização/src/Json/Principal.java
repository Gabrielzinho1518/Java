package Json;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Principal {

    public static void main(String[] args) {
        Pessoa p = new Pessoa("Ricardo", 30);

        JSONObject json = new JSONObject();
        json.put("Nome", p.getNome());
        json.put("idade", p.getIdade());

        gravaArquivo(json.toJSONString());

        try {
            lerArquivo();
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
    }

    public static void gravaArquivo(String jsonString) {
        try (FileWriter fileWriter = new FileWriter("pessoa.json")) {
            fileWriter.write(jsonString);
            System.out.println("Arquivo pessoa.json salvo com sucesso");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void lerArquivo() throws IOException, ParseException {
        JSONParser parser = new JSONParser();
        try (FileReader fileReader = new FileReader("pessoa.json")) {
            Object obj = parser.parse(fileReader);
            JSONObject jsonObject = (JSONObject) obj;

            String nome = (String) jsonObject.get("Nome");
            long idade = (long) jsonObject.get("idade");

            System.out.println("Nome: " + nome);
            System.out.println("Idade: " + idade);
        }
    }
}

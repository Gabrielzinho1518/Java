package pacote;

public class Passarinho extends Animal {
	public void emitirSom() {
		System.out.println("Piu piu");
	}
	

}

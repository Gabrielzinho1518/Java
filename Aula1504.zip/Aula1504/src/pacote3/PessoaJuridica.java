package pacote3;

public class PessoaJuridica extends Pessoa {
	
	protected String cnpj;
	protected String socio;
	protected String dtAbertura;
	public PessoaJuridica(String nome, int idade) {
		super(nome, idade);
		this.cnpj = cnpj;
		this.socio = socio;
		this.dtAbertura = "dtAbertura";
	}

}


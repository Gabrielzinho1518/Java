package pacote2;

public class Principal {

	public static void main(String[] args) {
		Cachorro c = new Cachorro();
		c.latir();
		c.nome = "bolt";
	}

}

package pacote;

public class Principal {

	public static void main(String[] args) {
		Carro c = new Carro();
		Onibus o = new Onibus();
		c.setNome("Fusca");
		c.nome = "herbit";
		c.exibeMsg();
		
		o.setModelo("ExpressoMedianeira");
		o.exibeMsg();
	}
	
}

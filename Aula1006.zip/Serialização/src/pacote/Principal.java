package pacote;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Principal {

	public static void main(String[] args) {
		Produto produto = new Produto("ABC123", "Exemplo de produto", 99, "Campo temporário");
		
		//Serialização
		try {
			FileOutputStream arquivoSaida = new FileOutputStream("Produto.ser");
			ObjectOutputStream objetoSaida = new ObjectOutputStream(arquivoSaida);
			
			objetoSaida.writeObject(produto);
			objetoSaida.close();
			arquivoSaida.close();
		
			System.out.println("Objeto serializado e salvo em produto.ser");
		 } catch (IOException e) {
			 e.printStackTrace();
			 
		 }
		try {
			FileInputStream arquivoEntrada = new FileInputStream("Produto.ser");
			ObjectInputStream objetoEntrada = new ObjectInputStream(arquivoEntrada);
					
		}catch (IOException e ) {
				e.printStackTrace();
		}
	}
}

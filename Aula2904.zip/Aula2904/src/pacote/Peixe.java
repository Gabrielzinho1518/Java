package pacote;

public class Peixe extends Animal {

}

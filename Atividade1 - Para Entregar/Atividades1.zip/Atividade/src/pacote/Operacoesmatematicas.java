package pacote;

import java.util.Scanner;

public class Operacoesmatematicas {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Digite um número:\n");
		double num1 = scanner.nextDouble();
		
		System.out.println("Digite o segundo numero:\n");
		double num2 = scanner.nextDouble();
		
		double soma = num1 + num2;
		double sub = num1 - num2;
		double div = num1 / num2;
		double mult = num1 * num2;
		
		System.out.println("Soma:"+soma);
		System.out.println("Subtração:"+sub);
		System.out.println("Divião:"+div);
		System.out.println("Multiplicação:"+mult);
		
	scanner.close();
	}

}

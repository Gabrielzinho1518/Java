package pacote2;

public class Principal {

	public static void main(String[] args) {
		Pessoa p = new Pessoa();
		p.nome = "Fernandinho";
		
		
		
		Programador pr = new Programador();
		pr.trabalhar();
	}

}

package pacote3;

public class Principal {

	public static void main(String[] args) {
		Pessoa p = new Pessoa("Ricardo",40);
		p.exibeDados();
		
		PessoaJuridica pj = new PessoaJuridica("ABC & CIA LTDA", 23);
		pj.exibeDados();
	}

}

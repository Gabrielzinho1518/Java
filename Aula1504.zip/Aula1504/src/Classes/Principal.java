package Classes;

public class Principal {

	public static void main(String[] args) {
		Quadrado q = new Quadrado(100,200,"Quadrado - Gabriel");
		q.nomeAutor = "Gabriel";
		q.exibeDados();
	}

}

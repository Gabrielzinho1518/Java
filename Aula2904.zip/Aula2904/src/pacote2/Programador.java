package pacote2;

public class Programador extends Pessoa {
	@Override
	public void trabalhar() {
		System.out.println("Eu estou programando");
	}

}

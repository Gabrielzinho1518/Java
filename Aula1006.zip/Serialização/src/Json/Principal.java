package Json;

import java.util.concurrent.*;
import java.io.IOException;
import org.json.simples.JSONArray;


public class Principal {

	public static void main(String[] args) {
		
		Pessoa p = new Pessoa("Ricardo", 30);
	
		JSONObject json = new JSONObject();
		json.put("Nome", p.getNome());
		json.put("idade", p.getIdade());
		String jsonString = json.toJSONString();
		
		gravaArquivo(jsonString);
		try {
			lerArquivo();
			
		} catch (org.json.simple.parser.ParseException e) {
			
			e.printStackTrace();
		} 
	}

	private static void lerArquivo() {
		// TODO Auto-generated method stub
		
	}
}

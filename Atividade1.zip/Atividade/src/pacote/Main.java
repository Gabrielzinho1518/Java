package pacote;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Disciplina disciplina = new Disciplina();

        System.out.println("Valores originais:");
        disciplina.recuperarValores();

        System.out.println("\nDigite o nome da disciplina:");
        String nome = sc.nextLine();

        System.out.println("Digite a carga horária:");
        double cargaHoraria = sc.nextDouble();
        sc.nextLine(); 

        System.out.println("Digite o nome do professor:");
        String nomeProfessor = sc.nextLine();

        disciplina.atribuirValores(nome, cargaHoraria, nomeProfessor);

        System.out.println("\nNovos valores:");
        disciplina.recuperarValores();

        sc.close();
    }
}

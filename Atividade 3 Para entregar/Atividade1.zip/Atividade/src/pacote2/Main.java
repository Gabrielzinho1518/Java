package pacote2;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Livro livro = new Livro();

        System.out.println("Digite o título do livro:");
        String titulo = sc.nextLine();

        System.out.println("Digite o autor:");
        String autor = sc.nextLine();

        System.out.println("Digite o ano de publicação:");
        int anoPublicacao = sc.nextInt();
        sc.nextLine(); 

        System.out.println("Digite o gênero:");
        String genero = sc.nextLine();

        livro.definirLivro(titulo, autor, anoPublicacao, genero);

        System.out.println("\nInformações do livro cadastrado:");
        System.out.println(livro.obterInformacoes());

        System.out.println("\nDeseja emprestar o livro? (s/n)");
        String resposta = sc.nextLine();

        if (resposta.equalsIgnoreCase("s")) {
            if (livro.emprestar()) {
                System.out.println("Livro emprestado com sucesso!");
            } else {
                System.out.println("O livro já está emprestado!");
            }
        }

        System.out.println("\nDeseja devolver o livro? (s/n)");
        resposta = sc.nextLine();

        if (resposta.equalsIgnoreCase("s")) {
            if (livro.devolver()) {
                System.out.println("Livro devolvido com sucesso!");
            } else {
                System.out.println("O livro já está disponível!");
            }
        }

        System.out.println("\nStatus atualizado do livro:");
        System.out.println(livro.obterInformacoes());

        sc.close();
    }
}

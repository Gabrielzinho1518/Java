package pacote;

import java.util.Scanner;

public class CidadePopulosa {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] cidades = new String[5];
        int[] populacoes = new int[5];
        
        for (int i = 0; i < 5; i++) {
            System.out.print("Digite o nome da " + (i + 1) + "ª cidade: ");
            cidades[i] = scanner.nextLine();
            System.out.print("Digite a população da cidade " + cidades[i] + ": ");
            populacoes[i] = scanner.nextInt();
            scanner.nextLine(); 
        }

        int indiceMaisPopulosa = 0;
        for (int i = 1; i < 5; i++) {
            if (populacoes[i] > populacoes[indiceMaisPopulosa]) {
                indiceMaisPopulosa = i;
            }
        }

        System.out.println("A cidade mais populosa é: " + cidades[indiceMaisPopulosa]);

        scanner.close();
    }
}

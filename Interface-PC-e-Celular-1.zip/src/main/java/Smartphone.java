public class Smartphone implements PC{
  String tel;
  String email;

  public Smartphone(String tel, String email) {
    super();
    this.tel = tel;
    this.email = email;
  }

  @Override
  public void verificaEmail() {
    System.out.println("Verificando e-mails");

  }

  @Override
  public void realizarChamada() {
    System.out.println("Realizando chamada...");
    System.out.println("Email abaixo:");
    System.out.println("Gabriel.saccol@ufn.edu.br");

  }

}

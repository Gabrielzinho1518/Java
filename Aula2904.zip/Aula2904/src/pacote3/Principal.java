package pacote3;

public class Principal {

	public static void main(String[] args) {
		Calculadora cal = new Calculadora();
		int resultado1 = cal.somar(2, 3);
		int resultado2 = cal.somar(2, 2, 5);
		double resultado3 = cal.somar(resultado1, resultado2);
		double resultado4 = cal.mult(2, 3);
		System.out.println("Resultado 1 = " +resultado1);
		System.out.println("Resultado 2 = " +resultado2);
		System.out.println("Resultado3: " + resultado3);
		System.out.println("Resutlado4: " + resultado4);
		}
	}



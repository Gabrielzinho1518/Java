public interface Celular {
  public void realizarChamada();

}

package pacote;

public class Hipopótamo extends Animal {

}

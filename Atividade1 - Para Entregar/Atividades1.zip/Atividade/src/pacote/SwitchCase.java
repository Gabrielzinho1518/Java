package pacote;

import java.util.Scanner;

public class SwitchCase {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Digite um número:\n");
		double num1 = scanner.nextDouble();
		
		System.out.println("Digite o segundo numero:\n");
		double num2 = scanner.nextDouble();
		
		double soma = num1 + num2;
		double sub = num1 - num2;
		double div = num1 / num2;
		double mult = num1 * num2;
		
		System.out.println("Escolha a operação: ");
	       System.out.println("1 - Soma");
	       System.out.println("2 - Subtração");
	       System.out.println("3 - Multiplicação");
	       System.out.println("4 - Divisão");
	       int escolha = scanner.nextInt();
        
        switch (escolha) {
            case 1:
                System.out.println("Resultado da soma: " + (num1 + num2));
                break;
            case 2:
                System.out.println("Resultado da subtração: " + (num1 - num2));
                break;
            case 3:
                System.out.println("Resultado da multiplicação: " + (num1 * num2));
                break;
            case 4: 
            	System.out.println("Resultado da divisão: " + (num1 / num2));
            	break;
            	default:
                System.out.println("Opção inválida!");
        }
        
	scanner.close();
	}

}

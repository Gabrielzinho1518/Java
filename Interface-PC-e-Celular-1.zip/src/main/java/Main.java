public class Main{
public static void main(String[] args) {
        Smartphone meuSmartphone = new Smartphone("123456789", "Gabriel@ufn.edu.br");
        meuSmartphone.verificaEmail();
        meuSmartphone.realizarChamada();
    }
}
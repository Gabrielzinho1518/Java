package Classes;

public class Desenho {
	protected String nomeAutor;
	
	public String getNomeAutor() {
		return nomeAutor;

	}
	public String setNomeAutor() {
		return this.nomeAutor = nomeAutor;
	}
	}


public interface PC {
  public void verificaEmail();

  void realizarChamada();

}

package pacote2;

public class Cachorro extends Animal {
	protected String raça;
	protected int idade;
	
	public void latir() {
		System.out.println("Au au");
		
	}
	

}

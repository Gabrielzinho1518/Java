package pacote2;

public class Pessoa {
	public String nome;
	
	public void trabalhar() {
	
	}

}

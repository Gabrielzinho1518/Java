package pacote2;

public class Animal {

	protected String nome;
	protected int idade;
	protected int som;
	
	public String getNome() {
		return nome;
	}
	
}

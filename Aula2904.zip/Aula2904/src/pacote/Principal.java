package pacote;

public class Principal {

	public static void main(String[] args) {
		Animal a = new Animal();
		a.nome = "Animal 1";
		a.emitirSom();

		Cachorro c = new Cachorro();
		c.nome = "caramelo";
		c.raca = "collie";
		c.emitirSom();
		
		Passarinho p = new Passarinho();
		p.emitirSom();
	}

}

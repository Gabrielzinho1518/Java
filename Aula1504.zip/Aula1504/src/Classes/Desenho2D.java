package Classes;

public class Desenho2D extends Desenho {
	protected int largura;
	protected int altura;
	
	public Desenho2D(int largura, int altura) {
		super();
		this.largura = largura;
		this.altura = altura;
	}

}

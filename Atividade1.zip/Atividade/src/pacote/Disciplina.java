/*
 * 1) Crie uma classe Disciplina que contenha os atributos (nome, carga horária e nome do professor)
 *  e os métodos de atribuir * e recuperar esses valores. Mostre na tela:
a) O conteúdo original dos atributos
b) A opção para o usuário inserir os valores
c) A exibição do novo conteúdo dos atributos
 */
package pacote;

import java.util.Scanner;

public class Disciplina {
    private String nome;
    private double cargaHoraria;
    private String nomeProfessor;

    public void atribuirValores(String n, double ch, String np) {
        nome = n;
        cargaHoraria = ch;
        nomeProfessor = np;
    }

    public void recuperarValores() {
        System.out.println("Nome da disciplina: " + nome);
        System.out.println("Carga horária: " + cargaHoraria + " horas");
        System.out.println("Nome do professor: " + nomeProfessor);
    }
}

package pacote;

import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class Menu {
    private static List<Veiculo> lista = new ArrayList<>();
    private static final String ARQUIVO = "veiculos.txt";

    public static void main(String[] args) {
        carregarArquivo();
        Scanner sc = new Scanner(System.in);
        int op;

        do {
            System.out.println("\n1 - Cadastrar veículo");
            System.out.println("2 - Alterar quilometragem");
            System.out.println("3 - Excluir veículo pela placa");
            System.out.println("4 - Listar veículos");
            System.out.println("5 - Sair");
            System.out.print("Escolha uma opção:");
            op = sc.nextInt();
            sc.nextLine();

            switch (op) {
                case 1 -> cadastrar(sc);
                case 2 -> alterar(sc);
                case 3 -> excluir(sc);
                case 4 -> listar();
                case 5 -> salvarArquivo();
                default -> System.out.println("Opção inválida.");
            }
        } while (op != 5);
        sc.close();
    }

    static void cadastrar(Scanner sc) {
        System.out.print("Placa: ");
        String placa = sc.nextLine();
        System.out.print("Modelo: ");
        String modelo = sc.nextLine();
        System.out.print("Marca: ");
        String marca = sc.nextLine();
        System.out.print("Ano de fabricação: ");
        int ano = sc.nextInt(); sc.nextLine();
        System.out.print("Quilometragem: ");
        double km = sc.nextDouble(); sc.nextLine();

        Veiculo v = new Veiculo(placa, modelo, marca, ano, km);
        lista.add(v);
        System.out.println("Veículo cadastrado!");
    }


    static void alterar(Scanner sc) {
        System.out.print("Placa: ");
        String placa = sc.nextLine();
        for (Veiculo v : lista) {
            if (v.getPlaca().equalsIgnoreCase(placa)) {
                System.out.print("Nova quilometragem: ");
                double km = sc.nextDouble(); sc.nextLine();
                v.setQuilometragem(km);
                System.out.println("Alterado com sucesso!");
                return;
            }
        }
        System.out.println("Veículo não encontrado.");
    }

    static void excluir(Scanner sc) {
        System.out.print("Placa: ");
        String placa = sc.nextLine();
        lista.removeIf(v -> v.getPlaca().equalsIgnoreCase(placa));
        System.out.println("Veiculo removido!).");
    }

    static void listar() {
        if (lista.isEmpty()) {
            System.out.println("Nenhum veículo.");
        } else {
            for (Veiculo v : lista) {
                System.out.println("Placa: " + v.getPlaca() +
                                   " | Modelo: " + v.getModelo() +
                                   " | Marca: " + v.getMarca() +
                                   " | Ano: " + v.getAno_de_fabricacao() +
                                   " | KM: " + v.getQuilometragem());
            }
        }
    }

    static void salvarArquivo() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ARQUIVO))) {
            for (Veiculo v : lista) {
                bw.write(v.toString());
                bw.newLine();
            }
            System.out.println("Salvo em " + ARQUIVO);
        } catch (IOException e) {
            System.out.println("Erro ao salvar: " + e.getMessage());
        }
    }

    static void carregarArquivo() {
        File file = new File(ARQUIVO);
        if (!file.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String linha;
            while ((linha = br.readLine()) != null) {
            	String[] partes = linha.split(";");
            	String placa = partes[0];
            	String modelo = partes[1];
            	String marca = partes[2];
            	int ano = Integer.parseInt(partes[3]);
            	double km = Double.parseDouble(partes[4]);
            	lista.add(new Veiculo(placa, modelo, marca, ano, km));

            }
        } catch (IOException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}

